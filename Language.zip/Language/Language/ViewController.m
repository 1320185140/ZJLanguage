//
//  ViewController.m
//  Language
//
//  Created by zj on 16/4/18.
//  Copyright © 2016年 zj. All rights reserved.
//

#import "ViewController.h"
#import "ZJInterNationalController.h"
#import "SecondViewController.h"
#define KScreen_Size [UIScreen mainScreen].bounds.size
@interface ViewController ()
@property(nonatomic,copy)UILabel * lable;
@property(nonatomic,copy)UIButton * Chinesebutton;
@property(nonatomic,copy)UIButton * Englishbutton;
@property(nonatomic,copy)NSString * Language;
@property(nonatomic,copy)NSString * Chinese;
@property(nonatomic,copy)NSString * English;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //注册通知，用于接收改变语言的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeLanguage) name:@"changeLanguage" object:nil];

    [ZJInterNationalController initUserLanguage];//初始化应用语言
    NSBundle *bundle = [ZJInterNationalController bundle];
    _Language=[bundle localizedStringForKey:@"Language" value:nil table:@"String"];
    _Chinese=[bundle localizedStringForKey:@"Chinese" value:nil table:@"String"];
    _English=[bundle localizedStringForKey:@"English" value:nil table:@"String"];
    [self addLable];
    
    [self addChineseButton];
    
    [self addEnglishButton];
}

-(void)changeLanguage{
    [_Chinesebutton setTitle:[[ZJInterNationalController bundle] localizedStringForKey:@"Chinese" value:nil table:@"String"] forState:UIControlStateNormal];
    
    [_Englishbutton setTitle:[[ZJInterNationalController bundle] localizedStringForKey:@"English" value:nil table:@"String"] forState:UIControlStateNormal];
    _lable.text=[[ZJInterNationalController bundle] localizedStringForKey:@"Language" value:nil table:@"String"];
}
-(void)addLable{
    _lable=[[UILabel alloc]init];
    _lable.frame=CGRectMake(10, 120, KScreen_Size.width-20,44);
    _lable.text=_Language;
    _lable.textAlignment=NSTextAlignmentCenter;
    _lable.backgroundColor=[UIColor yellowColor];
    [self.view addSubview:_lable];
}

-(void)addChineseButton{
    
    _Chinesebutton=[[UIButton alloc]init];
    _Chinesebutton.frame=CGRectMake(10,200, KScreen_Size.width-20,44);
    [_Chinesebutton setTitle:_Chinese forState:UIControlStateNormal];
    _Chinesebutton.backgroundColor=[UIColor redColor];
    [_Chinesebutton addTarget:self action:@selector(ChinesebuttonClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_Chinesebutton];
}
-(void)ChinesebuttonClicked{
    [self viewWillAppear:YES];
    [ZJInterNationalController setUserlanguage:@"zh-Hans"];
    //改变完成之后发送通知，告诉其他页面修改完成，提示刷新界面
    [[NSNotificationCenter defaultCenter] postNotificationName:@"changeLanguage" object:nil];

}


-(void)addEnglishButton{
    
    _Englishbutton=[[UIButton alloc]init];
    _Englishbutton.frame=CGRectMake(10,280, KScreen_Size.width-20,44);
    [_Englishbutton setTitle:_English forState:UIControlStateNormal];
    _Englishbutton.backgroundColor=[UIColor greenColor];
    [_Englishbutton addTarget:self action:@selector(EnglishbuttonClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_Englishbutton];
}
-(void)EnglishbuttonClicked{
    [ZJInterNationalController setUserlanguage:@"en"];
    //改变完成之后发送通知，告诉其他页面修改完成，提示刷新界面
    [[NSNotificationCenter defaultCenter] postNotificationName:@"changeLanguage" object:nil];

}

@end
